<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
    <title>404</title>
    <meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
</head>
<body>
<title>Ooops</title>
<br /><br /><br />
<center>
    <h1>Ooops! Erro 404</h1>
    <img src="app/images/default/404.jpg" />
    <h1>Página não encontrada!</h1>
    <a href="<?=($_GET['return'])? $_GET['return'] :  '#';?>">Voltar</a>
</center>
</body>
</html>
