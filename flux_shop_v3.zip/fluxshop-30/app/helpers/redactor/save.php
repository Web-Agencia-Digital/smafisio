<?php

echo stripslashes($_POST['data']);

?>